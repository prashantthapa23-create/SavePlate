// Sends the 2FA verification code. When MAIL_ENABLED is false the code
// is printed to the server console instead, so the prototype can be
// demonstrated without configuring an SMTP account.
const nodemailer = require('nodemailer');

const enabled = String(process.env.MAIL_ENABLED).toLowerCase() === 'true';

let transporter = null;
if (enabled) {
  transporter = nodemailer.createTransport({
    host: process.env.MAIL_HOST,
    port: Number(process.env.MAIL_PORT) || 587,
    secure: false,
    auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS },
  });
}

async function sendVerificationCode(email, code) {
  if (!enabled) {
    console.log(`\n  [2FA] Verification code for ${email}: ${code}\n`);
    return;
  }
  await transporter.sendMail({
    from: `"SavePlate" <${process.env.MAIL_USER}>`,
    to: email,
    subject: 'Your SavePlate verification code',
    text: `Your verification code is ${code}. It expires in 10 minutes.`,
  });
}

module.exports = { sendVerificationCode };
