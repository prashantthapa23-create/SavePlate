// Populates the database with two demo households so the Browse page and
// the Analytics dashboard have something to show during the presentation.
// Run with: npm run seed
require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('./config/db');

const day = n => {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};

async function seed() {
  console.log('Clearing existing data...');
  await pool.query('SET FOREIGN_KEY_CHECKS = 0');
  for (const t of ['NOTIFICATION', 'TWO_FA_CODE', 'DONATION_LISTING', 'FOOD_ITEM', 'PRIVACY_SETTINGS', 'USER']) {
    await pool.query(`TRUNCATE TABLE ${t}`);
  }
  await pool.query('SET FOREIGN_KEY_CHECKS = 1');

  const hash = await bcrypt.hash('Password123', 10);
  const users = [
    ['Sukriya KC', 'sukriya@saveplate.test', 4],
    ['Prashant Thapa', 'prashant@saveplate.test', 3],
    ['Aishah Rahman', 'aishah@saveplate.test', 5],
  ];

  const ids = [];
  for (const [name, email, size] of users) {
    const [r] = await pool.query(
      'INSERT INTO USER (full_name, email, password_hash, household_size) VALUES (?, ?, ?, ?)',
      [name, email, hash, size]
    );
    ids.push(r.insertId);
    await pool.query('INSERT INTO PRIVACY_SETTINGS (user_id) VALUES (?)', [r.insertId]);
  }
  const [u1, u2, u3] = ids;

  const items = [
    // owner, name, qty, expiry, category, location, status
    [u1, 'Chicken breast', 2, day(1),  'Meat & seafood', 'Fridge',  'active'],
    [u1, 'Fresh milk',     1, day(2),  'Dairy',          'Fridge',  'active'],
    [u1, 'Spinach',        1, day(3),  'Fresh produce',  'Fridge',  'active'],
    [u1, 'Rice 5kg',       1, day(180),'Dry goods',      'Pantry',  'active'],
    [u1, 'Bananas',        6, day(-2), 'Fresh produce',  'Counter', 'active'],
    [u1, 'Yoghurt',        4, day(-5), 'Dairy',          'Fridge',  'used'],
    [u1, 'Bread loaf',     1, day(-6), 'Bakery',         'Pantry',  'used'],
    [u1, 'Tomatoes',       5, day(-8), 'Fresh produce',  'Fridge',  'wasted'],
    [u1, 'Frozen peas',    2, day(90), 'Frozen',         'Freezer', 'active'],

    [u2, 'Canned tuna',    4, day(4),  'Canned',         'Pantry',  'donated'],
    [u2, 'Carrots',        8, day(5),  'Fresh produce',  'Fridge',  'donated'],
    [u2, 'Eggs',          12, day(6),  'Dairy',          'Fridge',  'active'],

    [u3, 'Wholemeal bread',2, day(2),  'Bakery',         'Pantry',  'donated'],
    [u3, 'Apples',         6, day(7),  'Fresh produce',  'Fridge',  'donated'],
    [u3, 'Cooking oil',    1, day(200),'Dry goods',      'Pantry',  'active'],
  ];

  const itemIds = {};
  for (const [user, name, qty, expiry, cat, loc, status] of items) {
    const [r] = await pool.query(
      `INSERT INTO FOOD_ITEM (user_id, item_name, quantity, expiry_date, category, storage_location, status)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [user, name, qty, expiry, cat, loc, status]
    );
    itemIds[name] = r.insertId;
  }

  const listings = [
    [itemIds['Canned tuna'],     u2, 'Bukit Jalil, Kuala Lumpur', 'Pickup after 6pm on weekdays.'],
    [itemIds['Carrots'],         u2, 'Bukit Jalil, Kuala Lumpur', 'Still crisp, bought this week.'],
    [itemIds['Wholemeal bread'], u3, 'Subang Jaya, Selangor',     'Two loaves, unopened.'],
    [itemIds['Apples'],          u3, 'Subang Jaya, Selangor',     'Half a tray, happy to split.'],
  ];
  for (const [item, poster, place, note] of listings) {
    await pool.query(
      'INSERT INTO DONATION_LISTING (item_id, posted_by, pickup_location, notes) VALUES (?, ?, ?, ?)',
      [item, poster, place, note]
    );
  }

  await pool.query('INSERT INTO NOTIFICATION (user_id, type, message) VALUES (?, ?, ?)',
    [u1, 'expiry', 'Chicken breast expires tomorrow. Use it or flag it for donation.']);

  console.log('\nSeed complete. Demo accounts (password: Password123):');
  users.forEach(u => console.log(`  ${u[1]}`));
  console.log('\nSign in as sukriya@saveplate.test to see inventory, analytics and 4 listings to browse.\n');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
