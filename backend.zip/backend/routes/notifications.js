const express = require('express');
const pool = require('../config/db');
const auth = require('../middleware/auth');

const router = express.Router();
router.use(auth);

router.get('/', async (req, res) => {
  const [rows] = await pool.query(
    'SELECT * FROM NOTIFICATION WHERE user_id = ? ORDER BY created_at DESC LIMIT 30',
    [req.userId]
  );
  const unread = rows.filter(r => !r.is_read).length;
  res.json({ notifications: rows, unread });
});

router.patch('/read', async (req, res) => {
  await pool.query('UPDATE NOTIFICATION SET is_read = TRUE WHERE user_id = ?', [req.userId]);
  res.json({ message: 'All notifications marked as read.' });
});

module.exports = router;
