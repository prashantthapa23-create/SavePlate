// UC1 - Register User & Privacy Settings (FR01-FR05)
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
const auth = require('../middleware/auth');
const { sendVerificationCode } = require('../config/mailer');

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function signToken(payload) {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30m',
  });
}

// ---------------------------------------------------------------- register
// US 1.1 / AC1-AC3
router.post('/register', async (req, res) => {
  const { full_name, email, password, household_size } = req.body;
  const errors = {};

  if (!full_name || full_name.trim().length < 2) errors.full_name = 'Enter your full name.';
  if (!email || !EMAIL_RE.test(email)) errors.email = 'Enter a valid email address.';
  if (!password || password.length < 8) errors.password = 'Use at least 8 characters.';

  if (Object.keys(errors).length) {
    return res.status(400).json({ message: 'Check the highlighted fields.', errors });
  }

  try {
    const [existing] = await pool.query('SELECT user_id FROM USER WHERE email = ?', [email]);
    if (existing.length) {
      // AC2 - duplicate email
      return res.status(409).json({
        message: 'That email is already registered.',
        errors: { email: 'That email is already registered.' },
      });
    }

    const password_hash = await bcrypt.hash(password, 10); // NFR103
    const [result] = await pool.query(
      'INSERT INTO USER (full_name, email, password_hash, household_size) VALUES (?, ?, ?, ?)',
      [full_name.trim(), email.toLowerCase(), password_hash, household_size || null]
    );

    // Every account starts with a privacy settings row (US 1.4).
    await pool.query('INSERT INTO PRIVACY_SETTINGS (user_id) VALUES (?)', [result.insertId]);
    await pool.query(
      'INSERT INTO NOTIFICATION (user_id, type, message) VALUES (?, ?, ?)',
      [result.insertId, 'account', 'Welcome to SavePlate. Add your first food item to get started.']
    );

    res.status(201).json({ message: 'Account created. You can sign in now.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Could not create the account. Try again.' });
  }
});

// ------------------------------------------------------------------- login
// US 1.2 / AC1-AC3
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const errors = {};
  if (!email) errors.email = 'Enter your email address.';
  if (!password) errors.password = 'Enter your password.';
  if (Object.keys(errors).length) {
    return res.status(400).json({ message: 'Fill in all required fields.', errors });
  }

  try {
    const [rows] = await pool.query('SELECT * FROM USER WHERE email = ?', [email.toLowerCase()]);
    const user = rows[0];
    // Same message for unknown email and wrong password, so the form does
    // not reveal which accounts exist.
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ message: 'That email and password do not match.' });
    }

    if (user.two_fa_enabled) {
      const code = String(Math.floor(100000 + Math.random() * 900000));
      await pool.query(
        'INSERT INTO TWO_FA_CODE (user_id, code, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))',
        [user.user_id, code]
      );
      await sendVerificationCode(user.email, code);
      return res.json({
        twoFactorRequired: true,
        pendingToken: signToken({ userId: user.user_id, pending2fa: true }),
        message: 'We sent a 6-digit code to your email.',
      });
    }

    res.json({
      token: signToken({ userId: user.user_id }),
      user: { user_id: user.user_id, full_name: user.full_name, email: user.email, two_fa_enabled: !!user.two_fa_enabled },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Could not sign you in. Try again.' });
  }
});

// -------------------------------------------------------------- verify 2FA
// US 1.3 / AC2-AC3
router.post('/verify-2fa', async (req, res) => {
  const { pendingToken, code } = req.body;
  if (!pendingToken || !code) {
    return res.status(400).json({ message: 'Enter the 6-digit code.' });
  }

  try {
    const payload = jwt.verify(pendingToken, process.env.JWT_SECRET);
    const [rows] = await pool.query(
      `SELECT * FROM TWO_FA_CODE
       WHERE user_id = ? AND code = ? AND used = FALSE AND expires_at > NOW()
       ORDER BY code_id DESC LIMIT 1`,
      [payload.userId, String(code).trim()]
    );

    if (!rows.length) {
      return res.status(401).json({ message: 'That code is incorrect or has expired. Enter it again.' });
    }

    await pool.query('UPDATE TWO_FA_CODE SET used = TRUE WHERE code_id = ?', [rows[0].code_id]);
    const [users] = await pool.query('SELECT * FROM USER WHERE user_id = ?', [payload.userId]);
    const user = users[0];

    res.json({
      token: signToken({ userId: user.user_id }),
      user: { user_id: user.user_id, full_name: user.full_name, email: user.email, two_fa_enabled: !!user.two_fa_enabled },
    });
  } catch (err) {
    res.status(401).json({ message: 'This verification attempt expired. Sign in again.' });
  }
});

// ---------------------------------------------------------------- /me
router.get('/me', auth, async (req, res) => {
  const [rows] = await pool.query(
    'SELECT user_id, full_name, email, two_fa_enabled, household_size FROM USER WHERE user_id = ?',
    [req.userId]
  );
  if (!rows.length) return res.status(404).json({ message: 'Account not found.' });
  res.json({ ...rows[0], two_fa_enabled: !!rows[0].two_fa_enabled });
});

// ---------------------------------------------------- 2FA toggle (US 1.3)
router.put('/two-factor', auth, async (req, res) => {
  const enabled = !!req.body.enabled;
  await pool.query('UPDATE USER SET two_fa_enabled = ? WHERE user_id = ?', [enabled, req.userId]);
  res.json({
    two_fa_enabled: enabled,
    message: enabled ? 'Two-factor authentication is on.' : 'Two-factor authentication is off.',
  });
});

// ----------------------------------------------- privacy settings (US 1.4)
router.get('/privacy', auth, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM PRIVACY_SETTINGS WHERE user_id = ?', [req.userId]);
  if (!rows.length) {
    await pool.query('INSERT INTO PRIVACY_SETTINGS (user_id) VALUES (?)', [req.userId]);
    return res.json({ profile_hidden: false, donations_hidden: false });
  }
  res.json({
    profile_hidden: !!rows[0].profile_hidden,
    donations_hidden: !!rows[0].donations_hidden,
  });
});

router.put('/privacy', auth, async (req, res) => {
  const profile_hidden = !!req.body.profile_hidden;
  const donations_hidden = !!req.body.donations_hidden;

  const [rows] = await pool.query('SELECT settings_id FROM PRIVACY_SETTINGS WHERE user_id = ?', [req.userId]);
  if (rows.length) {
    await pool.query(
      'UPDATE PRIVACY_SETTINGS SET profile_hidden = ?, donations_hidden = ? WHERE user_id = ?',
      [profile_hidden, donations_hidden, req.userId]
    );
  } else {
    await pool.query(
      'INSERT INTO PRIVACY_SETTINGS (user_id, profile_hidden, donations_hidden) VALUES (?, ?, ?)',
      [req.userId, profile_hidden, donations_hidden]
    );
  }

  res.json({ profile_hidden, donations_hidden, message: 'Privacy settings updated.' });
});

module.exports = router;
