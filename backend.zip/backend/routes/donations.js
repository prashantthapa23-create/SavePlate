// US 2.4 (flag for donation) and UC3 - Browse Food Items (FR11-FR14)
const express = require('express');
const pool = require('../config/db');
const auth = require('../middleware/auth');

const router = express.Router();
router.use(auth);

// Joined view used by both the browse list and the detail page.
const LISTING_SELECT = `
  SELECT l.listing_id, l.pickup_location, l.notes, l.listing_status, l.posted_at,
         l.posted_by, l.claimed_by,
         f.item_id, f.item_name, f.quantity, f.expiry_date, f.category, f.storage_location,
         u.full_name AS donor_name
  FROM DONATION_LISTING l
  JOIN FOOD_ITEM f ON f.item_id = l.item_id
  JOIN USER u ON u.user_id = l.posted_by
  LEFT JOIN PRIVACY_SETTINGS p ON p.user_id = l.posted_by
`;

// ------------------------------------------------- flag an item (US 2.4)
router.post('/', async (req, res) => {
  const { item_id, pickup_location, notes } = req.body;
  if (!item_id) return res.status(400).json({ message: 'Choose an item to donate.' });
  if (!pickup_location || !pickup_location.trim()) {
    return res.status(400).json({
      message: 'Enter a pickup location.',
      errors: { pickup_location: 'Enter a pickup location.' },
    });
  }

  const [items] = await pool.query(
    'SELECT * FROM FOOD_ITEM WHERE item_id = ? AND user_id = ?',
    [item_id, req.userId]
  );
  if (!items.length) return res.status(404).json({ message: 'That item is not in your inventory.' });

  const [dupes] = await pool.query(
    "SELECT listing_id FROM DONATION_LISTING WHERE item_id = ? AND listing_status = 'available'",
    [item_id]
  );
  if (dupes.length) return res.status(409).json({ message: 'This item is already listed for donation.' });

  const [result] = await pool.query(
    'INSERT INTO DONATION_LISTING (item_id, posted_by, pickup_location, notes) VALUES (?, ?, ?, ?)',
    [item_id, req.userId, pickup_location.trim(), notes || null]
  );
  await pool.query("UPDATE FOOD_ITEM SET status = 'donated' WHERE item_id = ?", [item_id]);
  await pool.query(
    'INSERT INTO NOTIFICATION (user_id, type, message) VALUES (?, ?, ?)',
    [req.userId, 'donation', `${items[0].item_name} is now listed for donation.`]
  );

  res.status(201).json({ listing_id: result.insertId, message: 'Listed for donation.' });
});

// ------------------------------------------------ browse (US 3.1 / 3.2)
router.get('/', async (req, res) => {
  const { category, location, expires_within } = req.query;

  // AC3 (US 3.1): the user's own listings never appear, and neither do
  // listings from users who hid their donations in privacy settings.
  const params = [req.userId];
  let sql = LISTING_SELECT + `
    WHERE l.listing_status = 'available'
      AND l.posted_by <> ?
      AND (p.donations_hidden IS NULL OR p.donations_hidden = FALSE)`;

  if (category && category !== 'all') { sql += ' AND f.category = ?'; params.push(category); }
  if (location && location !== 'all') { sql += ' AND l.pickup_location LIKE ?'; params.push(`%${location}%`); }
  if (expires_within && expires_within !== 'all') {
    sql += ' AND f.expiry_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)';
    params.push(Number(expires_within));
  }
  sql += ' ORDER BY f.expiry_date ASC';

  const [rows] = await pool.query(sql, params);
  res.json(rows);
});

// Distinct pickup areas, so the filter dropdown is built from real data.
router.get('/locations', async (req, res) => {
  const [rows] = await pool.query(
    "SELECT DISTINCT pickup_location FROM DONATION_LISTING WHERE listing_status = 'available' ORDER BY pickup_location"
  );
  res.json(rows.map(r => r.pickup_location));
});

// ---------------------------------------------------- my listings
router.get('/mine', async (req, res) => {
  const [rows] = await pool.query(LISTING_SELECT + ' WHERE l.posted_by = ? ORDER BY l.posted_at DESC', [req.userId]);
  res.json(rows);
});

router.get('/claimed', async (req, res) => {
  const [rows] = await pool.query(LISTING_SELECT + ' WHERE l.claimed_by = ? ORDER BY l.posted_at DESC', [req.userId]);
  res.json(rows);
});

// --------------------------------------------- listing detail (US 3.4)
router.get('/:id', async (req, res) => {
  const [rows] = await pool.query(LISTING_SELECT + ' WHERE l.listing_id = ?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ message: 'That listing no longer exists.' });
  const listing = rows[0];
  res.json({
    ...listing,
    is_own_listing: listing.posted_by === req.userId,
    can_claim: listing.listing_status === 'available' && listing.posted_by !== req.userId,
  });
});

// ------------------------------------------------------ claim (US 3.3)
router.post('/:id/claim', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Row lock prevents two users claiming the same listing at once.
    const [rows] = await conn.query(
      'SELECT * FROM DONATION_LISTING WHERE listing_id = ? FOR UPDATE',
      [req.params.id]
    );
    if (!rows.length) {
      await conn.rollback();
      return res.status(404).json({ message: 'That listing no longer exists.' });
    }

    const listing = rows[0];
    if (listing.posted_by === req.userId) {
      await conn.rollback();
      // FR14 - a user cannot claim their own donation.
      return res.status(403).json({ message: 'You cannot claim your own listing.' });
    }
    if (listing.listing_status === 'claimed') {
      await conn.rollback();
      // AC3 - someone else got there first.
      return res.status(409).json({ message: 'Someone has already claimed this item.' });
    }

    await conn.query(
      "UPDATE DONATION_LISTING SET listing_status = 'claimed', claimed_by = ? WHERE listing_id = ?",
      [req.userId, req.params.id]
    );

    const [items] = await conn.query('SELECT item_name FROM FOOD_ITEM WHERE item_id = ?', [listing.item_id]);
    const name = items[0] ? items[0].item_name : 'An item';

    // AC2 - both sides are notified.
    await conn.query('INSERT INTO NOTIFICATION (user_id, type, message) VALUES (?, ?, ?)',
      [req.userId, 'donation', `You claimed ${name}. Pickup: ${listing.pickup_location}.`]);
    await conn.query('INSERT INTO NOTIFICATION (user_id, type, message) VALUES (?, ?, ?)',
      [listing.posted_by, 'donation', `${name} has been claimed.`]);

    await conn.commit();
    res.json({ message: `You claimed ${name}. Pick it up at ${listing.pickup_location}.` });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    res.status(500).json({ message: 'Could not complete the claim. Try again.' });
  } finally {
    conn.release();
  }
});

// ----------------------------------------------------- cancel a listing
router.delete('/:id', async (req, res) => {
  const [rows] = await pool.query(
    'SELECT * FROM DONATION_LISTING WHERE listing_id = ? AND posted_by = ?',
    [req.params.id, req.userId]
  );
  if (!rows.length) return res.status(404).json({ message: 'That listing is not yours.' });
  if (rows[0].listing_status === 'claimed') {
    return res.status(409).json({ message: 'This listing has been claimed and cannot be withdrawn.' });
  }

  await pool.query('DELETE FROM DONATION_LISTING WHERE listing_id = ?', [req.params.id]);
  await pool.query("UPDATE FOOD_ITEM SET status = 'active' WHERE item_id = ?", [rows[0].item_id]);
  res.json({ message: 'Listing withdrawn. The item is back in your inventory.' });
});

module.exports = router;
