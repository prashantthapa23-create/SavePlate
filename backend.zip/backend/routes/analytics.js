// UC4 - Food Analytics (FR15-FR17)
// All figures are computed from FOOD_ITEM and DONATION_LISTING, so there
// is no separate analytics table to keep in sync.
const express = require('express');
const pool = require('../config/db');
const auth = require('../middleware/auth');

const router = express.Router();
router.use(auth);

// US 4.2 - weekly / monthly / custom range
function resolveRange(query) {
  const { period = 'monthly', from, to } = query;
  const end = to ? new Date(to) : new Date();
  let start;

  if (period === 'custom' && from) {
    start = new Date(from);
  } else if (period === 'weekly') {
    start = new Date(end); start.setDate(end.getDate() - 6);
  } else if (period === 'all') {
    start = new Date('2000-01-01');
  } else {
    start = new Date(end); start.setDate(end.getDate() - 29);
  }

  const fmt = d => d.toISOString().slice(0, 10);
  return { from: fmt(start), to: fmt(end) };
}

// An item counts as wasted when it expired while still active, or the
// user explicitly marked it wasted.
const WASTED_CLAUSE = "(status = 'wasted' OR (status = 'active' AND expiry_date < CURDATE()))";

// ------------------------------------------------------------- summary
// US 4.1 / US 4.4
router.get('/summary', async (req, res) => {
  const { from, to } = resolveRange(req.query);
  const args = [req.userId, from, to];

  const [[saved]] = await pool.query(
    "SELECT COUNT(*) AS n FROM FOOD_ITEM WHERE user_id = ? AND status = 'used' AND DATE(created_at) BETWEEN ? AND ?", args);
  const [[donated]] = await pool.query(
    "SELECT COUNT(*) AS n FROM FOOD_ITEM WHERE user_id = ? AND status = 'donated' AND DATE(created_at) BETWEEN ? AND ?", args);
  const [[wasted]] = await pool.query(
    `SELECT COUNT(*) AS n FROM FOOD_ITEM WHERE user_id = ? AND ${WASTED_CLAUSE} AND DATE(created_at) BETWEEN ? AND ?`, args);
  const [[active]] = await pool.query(
    "SELECT COUNT(*) AS n FROM FOOD_ITEM WHERE user_id = ? AND status = 'active' AND expiry_date >= CURDATE()", [req.userId]);
  const [[claimed]] = await pool.query(
    "SELECT COUNT(*) AS n FROM DONATION_LISTING WHERE posted_by = ? AND listing_status = 'claimed'", [req.userId]);

  const handled = saved.n + donated.n + wasted.n;

  res.json({
    range: { from, to },
    saved: saved.n,
    donated: donated.n,
    wasted: wasted.n,
    active: active.n,
    donations_claimed: claimed.n,
    total_tracked: handled,
    // AC2 (US 4.1) - the client shows an empty state when this is 0.
    has_data: handled > 0 || active.n > 0,
    save_rate: handled ? Math.round(((saved.n + donated.n) / handled) * 100) : 0,
  });
});

// ------------------------------------------------------ chart datasets
router.get('/breakdown', async (req, res) => {
  const { from, to } = resolveRange(req.query);

  // Outcome per category - stacked bar chart.
  const [byCategory] = await pool.query(
    `SELECT category,
            SUM(status = 'used')   AS saved,
            SUM(status = 'donated') AS donated,
            SUM(${WASTED_CLAUSE})  AS wasted
     FROM FOOD_ITEM
     WHERE user_id = ? AND DATE(created_at) BETWEEN ? AND ?
     GROUP BY category ORDER BY category`,
    [req.userId, from, to]
  );

  // Weekly trend - line chart.
  const [trend] = await pool.query(
    `SELECT DATE_FORMAT(created_at, '%x-W%v') AS week,
            SUM(status IN ('used','donated')) AS saved,
            SUM(${WASTED_CLAUSE})             AS wasted
     FROM FOOD_ITEM
     WHERE user_id = ? AND DATE(created_at) BETWEEN ? AND ?
     GROUP BY week ORDER BY week`,
    [req.userId, from, to]
  );

  res.json({
    range: { from, to },
    by_category: byCategory.map(r => ({
      category: r.category,
      saved: Number(r.saved),
      donated: Number(r.donated),
      wasted: Number(r.wasted),
    })),
    trend: trend.map(r => ({ week: r.week, saved: Number(r.saved), wasted: Number(r.wasted) })),
  });
});

// ----------------------------------------------- waste report (US 4.3)
router.get('/waste-report', async (req, res) => {
  const { from, to } = resolveRange(req.query);
  const [rows] = await pool.query(
    `SELECT item_id, item_name, category, quantity, expiry_date, storage_location
     FROM FOOD_ITEM
     WHERE user_id = ? AND ${WASTED_CLAUSE} AND DATE(created_at) BETWEEN ? AND ?
     ORDER BY expiry_date DESC`,
    [req.userId, from, to]
  );
  res.json({ range: { from, to }, items: rows, count: rows.length });
});

module.exports = router;
