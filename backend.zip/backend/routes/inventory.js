// UC2 - Manage Food Inventory (FR06-FR10)
const express = require('express');
const pool = require('../config/db');
const auth = require('../middleware/auth');

const router = express.Router();
router.use(auth);

const CATEGORIES = ['Fresh produce', 'Dairy', 'Meat & seafood', 'Bakery', 'Canned', 'Frozen', 'Dry goods', 'Other'];
const LOCATIONS = ['Fridge', 'Freezer', 'Pantry', 'Counter'];

function validate(body) {
  const errors = {};
  if (!body.item_name || !body.item_name.trim()) errors.item_name = 'Enter the item name.';
  if (!body.quantity || Number(body.quantity) < 1) errors.quantity = 'Enter a quantity of 1 or more.';
  if (!body.expiry_date) errors.expiry_date = 'Choose an expiry date.';
  if (!body.category) errors.category = 'Choose a category.';
  return errors;
}

// Days until expiry, and the flag the UI uses to highlight the row.
function decorate(item) {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const expiry = new Date(item.expiry_date + 'T00:00:00');
  const days = Math.round((expiry - today) / 86400000);
  return {
    ...item,
    days_to_expiry: days,
    expiry_state: days < 0 ? 'expired' : days <= 3 ? 'near_expiry' : 'fresh', // AC1, 3-day window
  };
}

// ------------------------------------------------------------------ list
router.get('/', async (req, res) => {
  const { status = 'active', location, search } = req.query;
  const params = [req.userId];
  let sql = 'SELECT * FROM FOOD_ITEM WHERE user_id = ?';

  if (status && status !== 'all') { sql += ' AND status = ?'; params.push(status); }
  if (location && location !== 'all') { sql += ' AND storage_location = ?'; params.push(location); }
  if (search) { sql += ' AND item_name LIKE ?'; params.push(`%${search}%`); }
  sql += ' ORDER BY expiry_date ASC';

  const [rows] = await pool.query(sql, params);
  res.json(rows.map(decorate));
});

router.get('/options', (_req, res) => res.json({ categories: CATEGORIES, locations: LOCATIONS }));

// ------------------------------------------------------------------- add
// US 2.1
router.post('/', async (req, res) => {
  const errors = validate(req.body);
  if (Object.keys(errors).length) {
    return res.status(400).json({ message: 'Check the highlighted fields.', errors });
  }

  const { item_name, quantity, expiry_date, category, storage_location } = req.body;
  const [result] = await pool.query(
    `INSERT INTO FOOD_ITEM (user_id, item_name, quantity, expiry_date, category, storage_location)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [req.userId, item_name.trim(), Number(quantity), expiry_date, category, storage_location || null]
  );

  const [rows] = await pool.query('SELECT * FROM FOOD_ITEM WHERE item_id = ?', [result.insertId]);
  const item = decorate(rows[0]);

  // AC3 - warn, but still save, when the date entered is already past.
  const warning = item.days_to_expiry < 0
    ? 'Saved. This item is already past its expiry date.'
    : item.days_to_expiry <= 3
      ? `Saved. This item expires in ${item.days_to_expiry} day(s) - consider donating it.`
      : null;

  if (item.expiry_state !== 'fresh') {
    await pool.query(
      'INSERT INTO NOTIFICATION (user_id, type, message) VALUES (?, ?, ?)',
      [req.userId, 'expiry', `${item.item_name} is expiring soon.`]
    );
  }

  res.status(201).json({ item, warning, message: 'Item added to your inventory.' });
});

// ------------------------------------------------------------------ edit
// US 2.2
router.put('/:id', async (req, res) => {
  const errors = validate(req.body);
  if (Object.keys(errors).length) {
    return res.status(400).json({ message: 'Check the highlighted fields.', errors });
  }

  const { item_name, quantity, expiry_date, category, storage_location, status } = req.body;
  const [result] = await pool.query(
    `UPDATE FOOD_ITEM
     SET item_name = ?, quantity = ?, expiry_date = ?, category = ?, storage_location = ?, status = COALESCE(?, status)
     WHERE item_id = ? AND user_id = ?`,
    [item_name.trim(), Number(quantity), expiry_date, category, storage_location || null,
     status || null, req.params.id, req.userId]
  );

  if (!result.affectedRows) return res.status(404).json({ message: 'That item is not in your inventory.' });

  const [rows] = await pool.query('SELECT * FROM FOOD_ITEM WHERE item_id = ?', [req.params.id]);
  res.json({ item: decorate(rows[0]), message: 'Changes saved.' });
});

// ---------------------------------------------------------------- delete
// US 2.3
router.delete('/:id', async (req, res) => {
  const [result] = await pool.query(
    'DELETE FROM FOOD_ITEM WHERE item_id = ? AND user_id = ?',
    [req.params.id, req.userId]
  );
  if (!result.affectedRows) return res.status(404).json({ message: 'That item is not in your inventory.' });
  res.json({ message: 'Item deleted.' });
});

// ------------------------------------------------------- mark used/wasted
router.patch('/:id/status', async (req, res) => {
  const { status } = req.body;
  if (!['active', 'used', 'wasted'].includes(status)) {
    return res.status(400).json({ message: 'Unknown status.' });
  }
  const [result] = await pool.query(
    'UPDATE FOOD_ITEM SET status = ? WHERE item_id = ? AND user_id = ?',
    [status, req.params.id, req.userId]
  );
  if (!result.affectedRows) return res.status(404).json({ message: 'That item is not in your inventory.' });
  res.json({ message: status === 'used' ? 'Marked as used.' : 'Marked as wasted.' });
});

// --------------------------------------------------- expiring soon (FR09)
router.get('/expiring', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT * FROM FOOD_ITEM
     WHERE user_id = ? AND status = 'active'
       AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)
     ORDER BY expiry_date ASC`,
    [req.userId]
  );
  res.json(rows.map(decorate));
});

module.exports = router;
