// Verifies the JWT sent in the Authorization header and attaches the
// user id to the request. Every protected route uses this.
const jwt = require('jsonwebtoken');

module.exports = function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: 'Sign in to continue.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.pending2fa) {
      return res.status(401).json({ message: 'Finish two-factor verification first.' });
    }
    req.userId = payload.userId;
    next();
  } catch (err) {
    // Covers both tampered tokens and the idle-timeout expiry (NFR104).
    return res.status(401).json({ message: 'Your session expired. Sign in again.' });
  }
};
