-- SavePlate — database schema
-- Matches the data dictionary in Assignment 1 Task 2.

DROP DATABASE IF EXISTS saveplate;
CREATE DATABASE saveplate CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE saveplate;

CREATE TABLE USER (
  user_id         INT AUTO_INCREMENT PRIMARY KEY,
  full_name       VARCHAR(100)  NOT NULL,
  email           VARCHAR(150)  NOT NULL UNIQUE,
  password_hash   VARCHAR(255)  NOT NULL,
  two_fa_enabled  BOOLEAN       DEFAULT FALSE,
  household_size  INT           NULL,
  created_at      DATETIME      DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE PRIVACY_SETTINGS (
  settings_id      INT AUTO_INCREMENT PRIMARY KEY,
  user_id          INT NOT NULL,
  profile_hidden   BOOLEAN DEFAULT FALSE,
  donations_hidden BOOLEAN DEFAULT FALSE,
  CONSTRAINT fk_privacy_user FOREIGN KEY (user_id)
    REFERENCES USER(user_id) ON DELETE CASCADE
);

CREATE TABLE FOOD_ITEM (
  item_id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id          INT NOT NULL,
  item_name        VARCHAR(100) NOT NULL,
  quantity         INT NOT NULL,
  expiry_date      DATE NOT NULL,
  category         VARCHAR(50) NOT NULL,
  storage_location VARCHAR(50) NULL,
  status           ENUM('active','used','donated','wasted') DEFAULT 'active',
  created_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_item_user FOREIGN KEY (user_id)
    REFERENCES USER(user_id) ON DELETE CASCADE
);

CREATE TABLE DONATION_LISTING (
  listing_id      INT AUTO_INCREMENT PRIMARY KEY,
  item_id         INT NOT NULL,
  posted_by       INT NOT NULL,
  claimed_by      INT NULL,
  pickup_location VARCHAR(150) NOT NULL,
  notes           VARCHAR(255) NULL,
  listing_status  ENUM('available','claimed') DEFAULT 'available',
  posted_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_listing_item   FOREIGN KEY (item_id)    REFERENCES FOOD_ITEM(item_id) ON DELETE CASCADE,
  CONSTRAINT fk_listing_poster FOREIGN KEY (posted_by)  REFERENCES USER(user_id)      ON DELETE CASCADE,
  CONSTRAINT fk_listing_claim  FOREIGN KEY (claimed_by) REFERENCES USER(user_id)      ON DELETE SET NULL
);

CREATE TABLE NOTIFICATION (
  notification_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id         INT NOT NULL,
  type            ENUM('expiry','donation','meal_plan','account') NOT NULL,
  message         VARCHAR(255) NOT NULL,
  is_read         BOOLEAN DEFAULT FALSE,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id)
    REFERENCES USER(user_id) ON DELETE CASCADE
);

-- Holds short-lived 2FA codes (US 1.3). Not user-facing.
CREATE TABLE TWO_FA_CODE (
  code_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  code       VARCHAR(6) NOT NULL,
  expires_at DATETIME NOT NULL,
  used       BOOLEAN DEFAULT FALSE,
  CONSTRAINT fk_2fa_user FOREIGN KEY (user_id)
    REFERENCES USER(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_item_user   ON FOOD_ITEM(user_id, status);
CREATE INDEX idx_item_expiry ON FOOD_ITEM(expiry_date);
CREATE INDEX idx_listing_st  ON DONATION_LISTING(listing_status);
